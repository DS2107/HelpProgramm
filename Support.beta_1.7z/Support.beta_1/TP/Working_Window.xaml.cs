﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Runtime.Caching;
using System.ServiceModel;
using System.Collections.ObjectModel;
using TP.ServiceReference1;

namespace TP
{
    public delegate object GetInfoSupportUser();

    /// <summary>
    /// Логика взаимодействия для Working_Window.xaml
    /// </summary>
    public partial class Working_Window : Window
    {
        public event showInfo GetInfoSupportUser;

        Service1Client ServiceContext;
        public MySupportSpecialist mySupportSpecialist;
        MyRequest myCurrentRequest;
        bool Window_State = true;

        public Working_Window(Service1Client ServiceContext)
        {
            InitializeComponent();
            this.ServiceContext = ServiceContext;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e) {
            try {
                mySupportSpecialist = (MySupportSpecialist)GetInfoSupportUser();
                //TextLogin.Content = mySupportSpecialist.Login;
                //TextID.Content = mySupportSpecialist.ID;

                ShowUndistributedRequests();
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try {
                this.DragMove();
            }
            catch (Exception) {

            }
        } // Window_MouseLeftButtonDown

        /// <summary>
        /// Если пользователь хочет разлогиниться 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_LogOut_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        } // Button_LogOut_Click

        /// <summary>
        /// Обработка двойного клика по заявке
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GridRequestsUndistributed_MouseDoubleClick(object sender, MouseButtonEventArgs e) {
            try {
                myCurrentRequest = (MyRequest)(((DataGrid)sender).SelectedItem);

                if (myCurrentRequest != null) {
                    Message_Window message_Window = new Message_Window(ServiceContext, mySupportSpecialist);
                    message_Window.getInfo += Message_Window_getInfo;
                    message_Window.ShowDialog();
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_NewUser_Click(object sender, RoutedEventArgs e) {
            NewUser();
        }

        private void Button_NewSupport_Click(object sender, RoutedEventArgs e) {
            NewSupport();
        }

        private void Button_NewProduct_Click(object sender, RoutedEventArgs e) {
            NewProduct();
        }

        private void Button_NewSubject_Click(object sender, RoutedEventArgs e) {
            NewSubject();
        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (e.Source is TabControl) {
                TabItem tab = (TabItem)(tabControl.SelectedItem);

                string s = tab.Name;

                switch (tab.Name) {
                    case "tabRequestsUndistributed":
                        ShowUndistributedRequests();
                        break;
                    case "tabRequestsInProgress":
                        ShowInProgressRequests();
                        break;
                    case "tabRequestsClose":
                        if (dateFrom.SelectedDate == null) {
                            DateTime dateTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1, 0, 0, 0);
                            dateFrom.SelectedDate = dateTime;
                        }
                        if (dateTo.SelectedDate == null) {
                            DateTime dateTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 23, 59);
                            dateTo.SelectedDate = dateTime;
                        }

                        ShowCloseRequests();
                        break;
                    case "tabSettings":
                        //TabControl2_SelectionChanged()
                        break;
                }
            }

        }

        private void TabControl2_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (e.Source is TabControl) {
                TabItem tab = (TabItem)(tabControl2.SelectedItem);
                string s = tab.Name;

                switch (tab.Name) {
                    case "tabSupport":
                        ShowSupport();
                        break;
                    case "tabUser":
                        ShowUser();
                        break;
                    case "tabProduct":
                        ShowProduct();
                        break;
                    case "tabSubject":
                        ShowSubject();
                        break;
                }
            }
        }

        private void GridSupport_MouseDoubleClick(object sender, MouseButtonEventArgs e) {
            try {
                MySupportSpecialist mySupportSpecialist = (MySupportSpecialist)(((DataGrid)sender).SelectedItem);

                if (mySupportSpecialist != null) {
                    EditSupport(mySupportSpecialist);
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void GridUser_MouseDoubleClick(object sender, MouseButtonEventArgs e) {
            try {
                MyUser myUser = (MyUser)(((DataGrid)sender).SelectedItem);

                if (myUser != null) {
                    EditUser(myUser);
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void GridProduct_MouseDoubleClick(object sender, MouseButtonEventArgs e) {
            try {
                MyProduct myProduct = (MyProduct)(((DataGrid)sender).SelectedItem);

                if (myProduct != null) {
                    EditProduct(myProduct);
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void GridSubject_MouseDoubleClick(object sender, MouseButtonEventArgs e) {
            try {
                MySubject mySubject = (MySubject)(((DataGrid)sender).SelectedItem);

                if (mySubject != null) {
                    EditSubject(mySubject);
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e) {
            ShowCloseRequests();
        }

        /// <summary>
        /// Создание нового пользователя
        /// </summary>
        private void NewUser() {
            NewUser_Window newUser = new NewUser_Window(ServiceContext);
            newUser.Show();
        }

        /// <summary>
        /// Редактирование пользователя
        /// </summary>
        private void EditUser(MyUser myUser) {
            NewUser_Window message_Window = new NewUser_Window(ServiceContext, myUser);
            message_Window.ShowDialog();
        }

        /// <summary>
        /// Создание нового пользователя техподдержки
        /// </summary>
        private void NewSupport() {
            NewSupport_Window newSupport = new NewSupport_Window(ServiceContext);
            newSupport.Show();
        }

        /// <summary>
        /// Редактирование тех. специалиста
        /// </summary>
        private void EditSupport(MySupportSpecialist mySupportSpecialist) {
            NewSupport_Window message_Window = new NewSupport_Window(ServiceContext, mySupportSpecialist);
            message_Window.ShowDialog();
        }

        /// <summary>
        /// Создание нового продукта
        /// </summary>
        private void NewProduct() {
            NewProduct_Window newProduct = new NewProduct_Window(ServiceContext);
            newProduct.Show();
        }

        /// <summary>
        /// Редактирование продукта
        /// </summary>
        private void EditProduct(MyProduct myProduct) {
            NewProduct_Window message_Window = new NewProduct_Window(ServiceContext, myProduct);
            message_Window.ShowDialog();
        }

        /// <summary>
        /// Создание новой темы обращения
        /// </summary>
        private void NewSubject() {
            try {
                NewSubject_Window newSubject = new NewSubject_Window(ServiceContext);
                newSubject.Show();
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Редактирование темы
        /// </summary>
        private void EditSubject(MySubject mySubject) {
            NewSubject_Window message_Window = new NewSubject_Window(ServiceContext, mySubject);
            message_Window.ShowDialog();
        }

        /// <summary>
        /// Отображение заявок со статусом "Входящие"
        /// </summary>
        private void ShowUndistributedRequests() {
            try {
                List<MyRequest> UndistributedRequests;
                UndistributedRequests = ServiceContext.Get_Undistributed_Requests().ToList();

                if (UndistributedRequests != null) {
                    ObservableCollection<MyRequest> observableCollection = new ObservableCollection<MyRequest>(UndistributedRequests);
                    CollectionViewSource collection = new CollectionViewSource() { Source = observableCollection };
                    gridRequestsUndistributed.ItemsSource = collection.View;
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }

            tabRequestsUndistributed.Header = "Входящие заявки " + gridRequestsUndistributed.Items.Count;
            if (gridRequestsInProgress.Items.Count > 0) {
                tabRequestsInProgress.Header = "Заявки в работе " + gridRequestsInProgress.Items.Count;
            }
        }

        /// <summary>
        /// Отображение заявок со статусом "В работе"
        /// </summary>
        private void ShowInProgressRequests() {
            try {
                List<MyRequest> InProgressRequests;
                InProgressRequests = ServiceContext.Get_InProgress_Requests(mySupportSpecialist.ID).ToList();
                
                if (InProgressRequests != null) {
                    ObservableCollection<MyRequest> observableCollection = new ObservableCollection<MyRequest>(InProgressRequests);
                    CollectionViewSource collection = new CollectionViewSource() { Source = observableCollection };
                    gridRequestsInProgress.ItemsSource = collection.View;

                    tabRequestsUndistributed.Header = "Входящие заявки " + gridRequestsUndistributed.Items.Count;
                    if (gridRequestsInProgress.Items.Count > 0) {
                        tabRequestsInProgress.Header = "Заявки в работе " + gridRequestsInProgress.Items.Count;
                    }
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }

            tabRequestsUndistributed.Header = "Входящие заявки " + gridRequestsUndistributed.Items.Count;
            if (gridRequestsInProgress.Items.Count > 0) {
                tabRequestsInProgress.Header = "Заявки в работе " + gridRequestsInProgress.Items.Count;
            }
        }

        /// <summary>
        /// Отображение закрытых заявок
        /// </summary>
        private void ShowCloseRequests() {
            try {
                SearchField searchField = SearchField.CompanyName;
                if (radioCompany.IsChecked == true) {
                    searchField = SearchField.CompanyName;
                }
                else if (radioFname.IsChecked == true) {
                    searchField = SearchField.Fname;
                }
                else if (radioLname.IsChecked == true) {
                    searchField = SearchField.Lname;
                }
                else if (radioLogin.IsChecked == true) {
                    searchField = SearchField.Login;
                }
                else if (radioProduct.IsChecked == true) {
                    searchField = SearchField.ProductName;
                }
                else if (radioSubject.IsChecked == true) {
                    searchField = SearchField.SubjectName;
                }

                List<MyRequest> myCurrentRequests;
                myCurrentRequests = ServiceContext.Search_In_Closed_Requests(searchField, textSearch.Text, dateFrom.SelectedDate.Value, dateTo.SelectedDate.Value).ToList();

                if (myCurrentRequests != null) {
                    ObservableCollection<MyRequest> observableCollection = new ObservableCollection<MyRequest>(myCurrentRequests);
                    CollectionViewSource collection = new CollectionViewSource() { Source = observableCollection };
                    gridRequestsInClose.ItemsSource = collection.View;
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }

            tabRequestsUndistributed.Header = "Входящие заявки " + gridRequestsUndistributed.Items.Count;
            if (gridRequestsInProgress.Items.Count > 0) {
                tabRequestsInProgress.Header = "Заявки в работе " + gridRequestsInProgress.Items.Count;
            }
        }

        /// <summary>
        /// Вывод в грид всех тех. специалистов
        /// </summary>
        private void ShowSupport() {
            try {
                List<MySupportSpecialist> mySupportSpecialists;
                mySupportSpecialists = ServiceContext.Get_All_SupportSpec().ToList();

                if (mySupportSpecialists != null) {
                    ObservableCollection<MySupportSpecialist> observableCollection = new ObservableCollection<MySupportSpecialist>(mySupportSpecialists);
                    CollectionViewSource collection = new CollectionViewSource() { Source = observableCollection };
                    gridSupport.ItemsSource = collection.View;
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Вывод в грид всех пользователей
        /// </summary>
        private void ShowUser() {
            try {
                List<MyUser> myUsers;
                myUsers = ServiceContext.Get_All_Users().ToList();

                if (myUsers != null) {
                    ObservableCollection<MyUser> observableCollection = new ObservableCollection<MyUser>(myUsers);
                    CollectionViewSource collection = new CollectionViewSource() { Source = observableCollection };
                    gridUser.ItemsSource = collection.View;
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Вывод в грид всех продуктов
        /// </summary>
        private void ShowProduct() {
            try {
                List<MyProduct> myProducts;
                myProducts = ServiceContext.Get_All_Products().ToList();

                if (myProducts != null) {
                    ObservableCollection<MyProduct> observableCollection = new ObservableCollection<MyProduct>(myProducts);
                    CollectionViewSource collection = new CollectionViewSource() { Source = observableCollection };
                    gridProduct.ItemsSource = collection.View;
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Вывод в грид всех тем
        /// </summary>
        private void ShowSubject() {
            try {
                List<MySubject> mySubjects;
                mySubjects = ServiceContext.Get_All_Subjects().ToList();

                if (mySubjects != null) {
                    ObservableCollection<MySubject> observableCollection = new ObservableCollection<MySubject>(mySubjects);
                    CollectionViewSource collection = new CollectionViewSource() { Source = observableCollection };
                    gridSubject.ItemsSource = collection.View;
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Делегат
        /// </summary>
        /// <returns></returns>
        private object Message_Window_getInfo() {
            return myCurrentRequest;
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e) {
            this.Close();
        }

        private void Button_MaxMin_Click(object sender, RoutedEventArgs e) {
            if (Window_State == true) {
                WindowState = WindowState.Maximized;
                Window_State = false;
            }
            else {
                WindowState = WindowState.Normal;
                Window_State = true;
            }
        }

        private void Button_Min_Click(object sender, RoutedEventArgs e) {
            WindowState = WindowState.Minimized;
        }

        private void Button_Exit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            ServiceContext.DisconnectSupporter(mySupportSpecialist.Login);
            main.Show();
            this.Close();
        } // Button_Exit_Click

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
            try {
                ServiceContext.DisconnectSupporter(mySupportSpecialist.Login);
            }
            catch (Exception) {

            }
        }

        private void Window_Closed(object sender, EventArgs e) {
            try {
                ServiceContext.DisconnectSupporter(mySupportSpecialist.Login);
            }
            catch (Exception) {

            }
        }

        private void Button_Help_Click(object sender, RoutedEventArgs e)
        {
            HelpWindow help = new HelpWindow();
            help.ShowDialog();

        } // Button_Help_Click
    }
}
