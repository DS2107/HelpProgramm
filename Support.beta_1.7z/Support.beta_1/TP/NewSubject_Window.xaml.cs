﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TP.ServiceReference1;

namespace TP {
    /// <summary>
    /// Логика взаимодействия для NewSubject_Window.xaml
    /// </summary>
    public partial class NewSubject_Window : Window {
        Service1Client ServiceContext;
        bool toChange;
        MySubject mySubject;
        List<MyProductLocal> myProductLocals;

        public NewSubject_Window(Service1Client ServiceContext) {
            InitializeComponent();
            this.ServiceContext = ServiceContext;
            this.toChange = false;
            mySubject = new MySubject();
        }

        public NewSubject_Window(Service1Client ServiceContext, MySubject mySubject) {
            InitializeComponent();
            this.ServiceContext = ServiceContext;
            this.toChange = true;
            this.mySubject = mySubject;
        }

        private void Button_OK_Click(object sender, RoutedEventArgs e) {
            mySubject.Name = TextName.Text;

            List<int> productIDs = new List<int>();
            foreach (MyProductLocal item in myProductLocals) {
                if (item.CheckBox == true) {
                    productIDs.Add(item.myProduct.ID);
                }
            }

            try {
                bool result = false;
                result = ServiceContext.Registr_New_Subject(mySubject, productIDs.ToArray(), toChange);

                if (result) {
                    this.Close();
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

       

        private void Window_Loaded(object sender, RoutedEventArgs e) {
            try {
                List<MyProduct> myProducts = ServiceContext.Get_All_Products().ToList();

                if (myProducts != null) {
                    myProductLocals = new List<MyProductLocal>();
                    foreach (MyProduct item in myProducts) {
                        MyProductLocal myProductLocal = new MyProductLocal();
                        myProductLocal.myProduct = item;
                        myProductLocals.Add(myProductLocal);
                    }

                    if (toChange == true) { // Поменять на true // mySubject.ID
                        TextName.Text = mySubject.Name;
                        myProducts = ServiceContext.Get_MyProduct_By_Subject(mySubject.ID).ToList();

                        foreach (MyProduct item in myProducts) {
                            foreach (MyProductLocal itemLocal in myProductLocals) {
                                if (item.ID == itemLocal.myProduct.ID) {
                                    itemLocal.checkBox = true;
                                }
                            }
                        }
                    }

                    ObservableCollection<MyProductLocal> observableCollection = new ObservableCollection<MyProductLocal>(myProductLocals);
                    CollectionViewSource collection = new CollectionViewSource() { Source = observableCollection };
                    gridProduct.ItemsSource = collection.View;
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.DragMove();
            }
            catch
            {

            }
        } // Window_MouseLeftButtonDown

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        } // Button_Close_Click
    }
}
