﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TP.ServiceReference1;

namespace TP {
    /// <summary>
    /// Логика взаимодействия для NewTheme_Window.xaml
    /// </summary>
    public partial class NewTheme_Window : Window {
        Service1Client ServiceContext;
        bool toChange;
        MySubject mySubject;

        public NewTheme_Window(Service1Client ServiceContext) {
            InitializeComponent();
            this.ServiceContext = ServiceContext;
            this.toChange = false;
            mySubject = new MySubject();
        }

        public NewTheme_Window(Service1Client ServiceContext, MySubject mySubject) {
            InitializeComponent();
            this.ServiceContext = ServiceContext;
            this.toChange = true;
            this.mySubject = mySubject;
        }

        private void Button_OK_Click(object sender, RoutedEventArgs e) {
            mySubject.Name = TextName.Text;

            List<int> productIDs = new List<int>();

            try {
                bool result = false;
                result = ServiceContext.Registr_New_Subject(mySubject, productIDs.ToArray(), toChange);

                if (result) {
                    this.Close();
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Cancel_Click(object sender, RoutedEventArgs e) {
            this.Close();
        }
    }
}
