﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ServiceModel;
using TP.ServiceReference1;

namespace TP
{
    public partial class MainWindow : Window
    {

        Service1Client ServiceContext;
        MySupportSpecialist mySupportSpecialist;

        public MainWindow()
        {
            InitializeComponent();
            TB_Login.Focus();
            ServiceContext = new Service1Client();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                this.Close();
            } // if

        } // Window_KeyDown

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try {
                this.DragMove();
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
            
        }

        /// <summary>
        /// Авторизация пользователя
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TBlock_autorization_MouseLeftButtonDown(object sender, MouseButtonEventArgs e) {
            try {
                mySupportSpecialist = ServiceContext.SupporterConnection(TB_Login.Text, PB_Password.Password);

                // Test
                //mySupportSpecialist = new MySupportSpecialist();
                //mySupportSpecialist.ID = 0;
                //mySupportSpecialist.Lname = "Ivan";
                //mySupportSpecialist.Fname = "Petrov";
                //mySupportSpecialist.Login = "ipetrov";
                //mySupportSpecialist.Password = "123";
                //mySupportSpecialist.Address = "Don";
                // test

                if (mySupportSpecialist != null) {
                    Working_Window work = new Working_Window(ServiceContext);
                    work.mySupportSpecialist = mySupportSpecialist;
                    work.GetInfoSupportUser += Work_GetInfoSupportUser;
                    work.Show();
                    this.Close();
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Делегат передачи инфы о юзере
        /// </summary>
        /// <returns></returns>
        private object Work_GetInfoSupportUser() {
            return mySupportSpecialist;
        }

        private void TB_Login_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                try
                {
                    mySupportSpecialist = ServiceContext.SupporterConnection(TB_Login.Text, PB_Password.Password);

                    // Test
                    //mySupportSpecialist = new MySupportSpecialist();
                    //mySupportSpecialist.ID = 0;
                    //mySupportSpecialist.Lname = "Ivan";
                    //mySupportSpecialist.Fname = "Petrov";
                    //mySupportSpecialist.Login = "ipetrov";
                    //mySupportSpecialist.Password = "123";
                    //mySupportSpecialist.Address = "Don";
                    // test

                    if (mySupportSpecialist != null)
                    {
                        Working_Window work = new Working_Window(ServiceContext);
                        work.mySupportSpecialist = mySupportSpecialist;
                        work.GetInfoSupportUser += Work_GetInfoSupportUser;
                        work.Show();
                        this.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void PB_Password_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                try
                {
                    mySupportSpecialist = ServiceContext.SupporterConnection(TB_Login.Text, PB_Password.Password);

                    // Test
                    //mySupportSpecialist = new MySupportSpecialist();
                    //mySupportSpecialist.ID = 0;
                    //mySupportSpecialist.Lname = "Ivan";
                    //mySupportSpecialist.Fname = "Petrov";
                    //mySupportSpecialist.Login = "ipetrov";
                    //mySupportSpecialist.Password = "123";
                    //mySupportSpecialist.Address = "Don";
                    // test

                    if (mySupportSpecialist != null)
                    {
                        Working_Window work = new Working_Window(ServiceContext);
                        work.mySupportSpecialist = mySupportSpecialist;
                        work.GetInfoSupportUser += Work_GetInfoSupportUser;
                        work.Show();
                        this.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
