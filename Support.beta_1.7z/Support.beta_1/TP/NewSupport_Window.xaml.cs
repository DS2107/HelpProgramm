﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TP.ServiceReference1;

namespace TP {
    /// <summary>
    /// Логика взаимодействия для NewSupport_Windows.xaml
    /// </summary>
    public partial class NewSupport_Window : Window {

        Service1Client ServiceContext;
        MySupportSpecialist mySupportSpecialist;
        bool toChange;

        public NewSupport_Window(Service1Client ServiceContext) {
            InitializeComponent();
            this.ServiceContext = ServiceContext;
            mySupportSpecialist = new MySupportSpecialist();
            toChange = false;
        }

        public NewSupport_Window(Service1Client ServiceContext, MySupportSpecialist mySupportSpecialist) {
            InitializeComponent();
            this.ServiceContext = ServiceContext;
            this.mySupportSpecialist = mySupportSpecialist;
            toChange = true;
        }

        private void Button_OK_Click(object sender, RoutedEventArgs e) {
            try {
                if (TextPass.Password == TextPass2.Password) {
                    mySupportSpecialist.Lname = TextLname.Text;
                    mySupportSpecialist.Fname = TextFname.Text;
                    mySupportSpecialist.Login = TextLogin.Text;
                    mySupportSpecialist.Password = TextPass.Password;
                    mySupportSpecialist.Address = TextAddress.Text;

                    bool result = ServiceContext.Register_New_Support_Spesialist(mySupportSpecialist, toChange);

                    if (result) {
                        this.Close();
                    }
                    else {
                        MessageBox.Show("Неизвестная ошибка");
                    }
                }
                else {
                    MessageBox.Show("Пароли не совпадают!!!");
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

       

        private void Window_Loaded(object sender, RoutedEventArgs e) {
            try {
                if (toChange == true) { // Поменять на true
                    TextAddress.Text = mySupportSpecialist.Address;
                    TextFname.Text = mySupportSpecialist.Fname;
                    TextLname.Text = mySupportSpecialist.Lname;
                    TextLogin.Text = mySupportSpecialist.Login;
                    TextPass.Password = mySupportSpecialist.Password;
                    TextPass2.Password = mySupportSpecialist.Password;
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        } // Button_Close_Click

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.DragMove();
            }
            catch
            {

            }
        } // Window_MouseLeftButtonDown
    }
}
