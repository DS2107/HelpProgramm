﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using TP.ServiceReference1;

namespace TP {
    class MyProductLocal {
        public MyProduct myProduct { get; set; }

        public bool CheckBox {
            get {
                return checkBox;
            }
            set {
                checkBox = value;
            }
        }

        public bool checkBox = false;
    }
}
