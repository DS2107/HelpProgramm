﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TP.ServiceReference1;

namespace TP
{
    /// <summary>
    /// Логика взаимодействия для NewUser_Windows.xaml
    /// </summary>
    public partial class NewUser_Window : Window
    {
        Service1Client ServiceContext;
        MyProduct[] myProducts;
        List<MyProductLocal> myProductLocals;
        MyUser myUser; 
        bool toChange;

        public NewUser_Window(Service1Client ServiceContext)
        {
            InitializeComponent();
            this.ServiceContext = ServiceContext;
            myUser = new MyUser();
            toChange = false;
        }

        public NewUser_Window(Service1Client ServiceContext, MyUser myUser) {
            InitializeComponent();
            this.ServiceContext = ServiceContext;
            this.myUser = myUser;
            toChange = true;
        }

        private void CheckPriority2_Checked(object sender, RoutedEventArgs e) {
            CheckPriority1.IsChecked = true;
            CheckPriority2.IsChecked = true;
            CheckPriority3.IsChecked = false;
            CheckPriority4.IsChecked = false;
            CheckPriority5.IsChecked = false;
        }

        private void CheckPriority3_Checked(object sender, RoutedEventArgs e) {
            CheckPriority1.IsChecked = true;
            CheckPriority2.IsChecked = true;
            CheckPriority3.IsChecked = true;
            CheckPriority4.IsChecked = false;
            CheckPriority5.IsChecked = false;
        }

        private void CheckPriority4_Checked(object sender, RoutedEventArgs e) {
            CheckPriority1.IsChecked = true;
            CheckPriority2.IsChecked = true;
            CheckPriority3.IsChecked = true;
            CheckPriority4.IsChecked = true;
            CheckPriority5.IsChecked = false;
        }

        private void CheckPriority5_Checked(object sender, RoutedEventArgs e) {
            CheckPriority1.IsChecked = true;
            CheckPriority2.IsChecked = true;
            CheckPriority3.IsChecked = true;
            CheckPriority4.IsChecked = true;
            CheckPriority5.IsChecked = true;
        }

        private void CheckPriority1_Unchecked(object sender, RoutedEventArgs e) {
            CheckPriority1.IsChecked = true;
            CheckPriority5.IsChecked = false;
            CheckPriority4.IsChecked = false;
            CheckPriority3.IsChecked = false;
            CheckPriority2.IsChecked = false;
        }

        private void CheckPriority2_Unchecked(object sender, RoutedEventArgs e) {
            //CheckPriority1.IsChecked = true;
            CheckPriority5.IsChecked = false;
            CheckPriority4.IsChecked = false;
            CheckPriority3.IsChecked = false;
            //CheckPriority2.IsChecked = false;    
        }

        private void CheckPriority3_Unchecked(object sender, RoutedEventArgs e) {
            //CheckPriority1.IsChecked = true;
            //CheckPriority2.IsChecked = true;
            CheckPriority5.IsChecked = false;
            CheckPriority4.IsChecked = false;
            //CheckPriority3.IsChecked = false;
        }

        private void CheckPriority4_Unchecked(object sender, RoutedEventArgs e) {
            //CheckPriority1.IsChecked = true;
            //CheckPriority2.IsChecked = true;
            //CheckPriority3.IsChecked = true;
            CheckPriority5.IsChecked = false;
            //CheckPriority4.IsChecked = false;
            
        }

        private void CheckPriority5_Unchecked(object sender, RoutedEventArgs e) {
            //CheckPriority1.IsChecked = true;
            //CheckPriority2.IsChecked = true;
            //CheckPriority3.IsChecked = true;
            //CheckPriority4.IsChecked = true;
            //CheckPriority5.IsChecked = false;
        }

        private void Button_OK_Click(object sender, RoutedEventArgs e) {
            try {
                if (TextPass.Password == TextPass2.Password) {
                    List<int> productIDs = new List<int>();
                    foreach (MyProductLocal item in myProductLocals) {
                        if (item.CheckBox == true) {
                            productIDs.Add(item.myProduct.ID);
                        }
                    }

                    //MyUser myUser = new MyUser();

                    myUser.Lname = TextLname.Text;
                    myUser.Fname = TextFname.Text;
                    myUser.Login = TextLogin.Text;
                    myUser.Password = TextPass.Password;
                    myUser.CompanyName = TextCompanyName.Text;
                    myUser.Address = TextAddress.Text;
                    myUser.Support_Is_Active = (bool)CheckActive.IsChecked;

                    if (CheckPriority5.IsChecked == true) {
                        myUser.Priority = 5;
                    }
                    else if (CheckPriority4.IsChecked == true) {
                        myUser.Priority = 4;
                    }
                    else if (CheckPriority3.IsChecked == true) {
                        myUser.Priority = 3;
                    }
                    else if (CheckPriority2.IsChecked == true) {
                        myUser.Priority = 2;
                    }
                    else {
                        myUser.Priority = 1;
                    }

                    bool result = ServiceContext.Register_New_User(myUser, productIDs.ToArray(), toChange);

                    if (result) {
                        this.Close();
                    }
                }
                else {
                    MessageBox.Show("Пароли не совпадают!!!");
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

      

        /// <summary>
        /// Заполение окна при загрузке
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e) {
            try {
                myProducts = ServiceContext.Get_All_Products();

                if (myProducts != null) {
                    myProductLocals = new List<MyProductLocal>();
                    foreach (MyProduct item in myProducts) {
                        MyProductLocal myProductLocal = new MyProductLocal();
                        myProductLocal.myProduct = item;
                        myProductLocals.Add(myProductLocal);
                    }

                    if (toChange == true) { // Поменять на true
                        TextAddress.Text = myUser.Address;
                        TextCompanyName.Text = myUser.CompanyName;
                        TextFname.Text = myUser.Fname;
                        TextLname.Text = myUser.Lname;
                        TextLogin.Text = myUser.Login;
                        TextPass.Password = myUser.Password;
                        TextPass2.Password = myUser.Password;
                        CheckActive.IsChecked = myUser.Support_Is_Active;

                        switch (myUser.Priority) {
                            case 1:
                                CheckPriority1.IsChecked = true;
                                break;
                            case 2:
                                CheckPriority2.IsChecked = true;
                                break;
                            case 3:
                                CheckPriority3.IsChecked = true;
                                break;
                            case 4:
                                CheckPriority4.IsChecked = true;
                                break;
                            case 5:
                                CheckPriority5.IsChecked = true;
                                break;
                        }

                        myProducts = ServiceContext.Get_MyProduct_By_User(myUser.ID);

                        foreach (MyProduct item in myProducts) {
                            foreach (MyProductLocal itemLocal in myProductLocals) {
                                if (item.ID == itemLocal.myProduct.ID) {
                                    itemLocal.checkBox = true;
                                }
                            }
                        }
                    }

                    ObservableCollection<MyProductLocal> observableCollection = new ObservableCollection<MyProductLocal>(myProductLocals);
                    CollectionViewSource collection = new CollectionViewSource() { Source = observableCollection };
                    gridProductUser.ItemsSource = collection.View;
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.DragMove();
            }
           catch
            {

            }
        } // Window_MouseLeftButtonDown

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
