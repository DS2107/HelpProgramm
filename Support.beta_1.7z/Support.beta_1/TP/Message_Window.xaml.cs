﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using TP.ServiceReference1;
using System.IO;
using System.Windows.Media.Effects;
using System.Diagnostics;

namespace TP
{
    public delegate object showInfo();

    /// <summary>
    /// Логика взаимодействия для Message_Window.xaml
    /// </summary>
    public partial class Message_Window : Window
    {
        public event showInfo getInfo;
        Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
        List<string> MyImage;
        MyFile myFile;
        MyContact myContact = new MyContact();
        Service1Client ServiceContext;
        List<MyContact> myContacts;
        MyRequest myCurrentRequest;
        MySupportSpecialist supportSpecialist;
        MySupportSpecialist currentSupportSpecialist;
        int countContact;

        public Message_Window(Service1Client ServiceContext, MySupportSpecialist supportSpecialist)
        {
            InitializeComponent();
            this.ServiceContext = ServiceContext;
            this.supportSpecialist = supportSpecialist;
            Button_StatusChange.Tag = false;
            L_Count.Visibility = Visibility.Collapsed;
            TextBox_Message.MaxLength = 1000;
        }

        /// <summary>
        /// Заполнение окна переписки
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e) {
            try {
                countContact = 0;

                myCurrentRequest = (MyRequest)getInfo();

                RequestStatus requestStatus = myCurrentRequest.Status;
                if (requestStatus.ID == 1 || requestStatus.ID == 5) {
                    Button_StatusChange.Tag = false;
                    Button_StatusChange.Content = "Взять в рботу";

                    Button_StatusClose.IsEnabled = false;
                    Button_Ok.IsEnabled = false;
                    Button_File.IsEnabled = false;

                    TextBox_Message.IsEnabled = false;
                }
                else if (requestStatus.ID == 2) {
                    Button_StatusChange.Tag = true;
                    Button_StatusChange.Content = "Вернуть в входящие";

                    Button_StatusClose.IsEnabled = true;
                    Button_Ok.IsEnabled = true;
                    Button_File.IsEnabled = true;

                    TextBox_Message.IsEnabled = true;

                    currentSupportSpecialist = ServiceContext.Get_SupportSpecialist_Info(myCurrentRequest.Belong_To_Support_ID);
                }
                else if (requestStatus.ID == 6) {
                    Button_StatusChange.Content = "Вернуть в входящие";

                    Button_StatusChange.IsEnabled = false;
                    Button_StatusClose.IsEnabled = false;
                    Button_Ok.IsEnabled = false;
                    Button_File.IsEnabled = false;

                    TextBox_Message.IsEnabled = false;

                    currentSupportSpecialist = ServiceContext.Get_SupportSpecialist_Info(myCurrentRequest.Belong_To_Support_ID);
                }
                
                // Заполнение полей о сотруднике в выезжающем окне
                if (currentSupportSpecialist != null) {
                    TextId.Text = currentSupportSpecialist.ID.ToString();
                    TextFname.Text = currentSupportSpecialist.Fname;
                    TextLname.Text = currentSupportSpecialist.Lname;
                }

                if (myCurrentRequest != null) {
                    myContacts = ServiceContext.Get_Full_LOG_Of_Current_Request(myCurrentRequest.ID, false).ToList();

                    bool flag = false;

                    foreach (MyContact myContact in myContacts) {
                        ListBoxItem listItem = new ListBoxItem();
                        ListBoxItem listItem2 = new ListBoxItem();
                        if (flag) {
                            listItem.Content = "";
                            ListMessage.Items.Add(listItem);
                        }
                        else {
                            flag = true;
                        }

                        countContact++;
                        string s = myContact.DateTime.ToString() + " " + myContact.Author.Fname + " " + myContact.Author.Lname;
                        TextBlock textBlock = new TextBlock();
                        TextBlock textBlockS = new TextBlock();
                        textBlockS.Background = new SolidColorBrush(Color.FromRgb(231, 234, 237));
                        textBlockS.Text = s;
                        textBlockS.FontSize = 14;
                        textBlock.Width = 600;
                        textBlock.FontSize = 18;
                        
                        
                        textBlock.Foreground = new SolidColorBrush(Colors.White);

                        if (!myContact.IsFromClient)
                            textBlock.Background = new SolidColorBrush(Color.FromRgb(47, 123, 195));
                        else
                            textBlock.Background = new SolidColorBrush(Color.FromRgb(51, 52, 51));
                    
                        textBlock.Text = myContact.Message;
                        textBlock.TextWrapping = TextWrapping.Wrap;


                        listItem = new ListBoxItem();
                        listItem2 = new ListBoxItem();
                        listItem.Focusable = false;
                        
                        listItem.Content = textBlock;
                        listItem2.Content = textBlockS;
                        listItem.Width = ListMessage.ActualWidth - 15;
                        ListMessage.Items.Add(listItem2);

                        ListMessage.Items.Add(listItem);
                        ListMessage.ScrollIntoView(listItem);

                        try {
                            int countFile = 0;
                            foreach (MyFile myFile in myContact.ScreenShots) {
                                countFile++;
                                if (myFile.Extansion == ".jpg" || myFile.Extansion == ".bmp" || myFile.Extansion == ".png") {
                                    var ms = new System.IO.MemoryStream(myFile.FileArray);
                                    BitmapImage bitmapImage = new BitmapImage();
                                    bitmapImage.BeginInit();
                                    bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                                    bitmapImage.StreamSource = ms;
                                    bitmapImage.EndInit();

                                    Image image = new Image();
                                    image.Source = bitmapImage;
                                    image.Width = 180;

                                    listItem = new ListBoxItem();
                                    Border border = new Border();
                                    border.Child = image;
                                    border.BorderThickness = new Thickness(5, 5, 5, 5);
                                    if (!myContact.IsFromClient)
                                        border.BorderBrush = new SolidColorBrush(Color.FromRgb(47, 123, 195));
                                    else
                                        border.BorderBrush = new SolidColorBrush(Color.FromRgb(51, 52, 51));
                                    listItem.Content = border;

                                    List<object> list = new List<object>();
                                    list.Add(myCurrentRequest.ID + "\\" + myContact.ID); // имя папки
                                    list.Add(myCurrentRequest.ID + "\\" + myContact.ID + "\\" + countFile + myFile.Extansion); // имя картинки
                                    list.Add(null); // массив
                                    listItem.Tag = list;

                                    listItem.Width = ListMessage.ActualWidth - 15;
                                    //ListMessage.Items.Add(s);
                                    ListMessage.Items.Add(listItem);
                                    ListMessage.ScrollIntoView(listItem);
                                }
                                else {
                                    Image image = new Image();
                                    Uri iconUri = new Uri(@"Image/document.png", UriKind.Relative);
                                    image.Source = BitmapFrame.Create(iconUri);
                                    image.Width = 180;

                                    image.Tag = myFile.FileArray;

                                    listItem = new ListBoxItem();
                                    Border border = new Border();
                                    border.Child = image;
                                    border.BorderThickness = new Thickness(5, 5, 5, 5);
                                    if (!myContact.IsFromClient)
                                        border.BorderBrush = new SolidColorBrush(Color.FromRgb(47, 123, 195));
                                    else
                                        border.BorderBrush = new SolidColorBrush(Color.FromRgb(51, 52, 51));
                                    listItem.Content = border;

                                    List<object> list = new List<object>();
                                    list.Add(myCurrentRequest.ID + "\\" + countContact); // имя папки
                                    list.Add(myCurrentRequest.ID + "\\" + myContact.ID + "\\" + countFile + myFile.Extansion); // имя картинки
                                    list.Add(myFile.FileArray); // массив
                                    listItem.Tag = list;

                                    listItem.Width = ListMessage.ActualWidth - 15;
                                    //ListMessage.Items.Add(s);
                                    ListMessage.Items.Add(listItem);
                                    ListMessage.ScrollIntoView(listItem);
                                }
                            }
                        }
                        catch (Exception) {

                        }

                        //listItem = new ListBoxItem();
                        //listItem.Content = "\n";
                        //ListMessage.Items.Add(listItem);
                    }
                }
                else {
                    MessageBox.Show("Не удалось прочитать информацию о запросе");
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_File_Click(object sender, RoutedEventArgs e) {
            dlg.Multiselect = true;
            Nullable<bool> result = dlg.ShowDialog();

            MyImage = new List<string>();
            int cout = 0;
            if (result == true) {
                List<MyFile> list = new List<MyFile>();

                for (int i = 0; i < dlg.FileNames.Length; i++) {
                    MyImage.Add(dlg.FileNames[i]);
                    if (MyImage.Count == 4)
                        break;

                    FileInfo file = new FileInfo(dlg.FileNames[i].ToString());
                    myFile = new MyFile();
                    myFile.Extansion = file.Extension;
                    myFile.FileArray = File.ReadAllBytes(dlg.FileNames[i].ToString());
                    cout++;
                    list.Add(myFile);
                    
                }
                myContact.ScreenShots = list.ToArray();
                L_Count.Content = cout.ToString();
                L_Count.Visibility = Visibility.Visible;
            }
           
           
        }

        private void Button_Send_Click(object sender, RoutedEventArgs e) {
            try {
               
                    Author author = new Author();
                    author.ID = supportSpecialist.ID;
                    author.Lname = supportSpecialist.Lname;
                    author.Fname = supportSpecialist.Fname;

                    myContact.Author = author;
                    myContact.Request_ID = myCurrentRequest.ID;
                    myContact.Message = TextBox_Message.Text;
                    myContact.IsFromClient = false;

                    if (myContact.ScreenShots == null) {
                        myContact.ScreenShots = (new List<MyFile>()).ToArray();
                    }
                    myContact.FilesCount = myContact.ScreenShots.Count();
                    
                    bool result = ServiceContext.Post_Appeal_Inside_Request(myCurrentRequest, myContact);

                    if (result) {
                        countContact++;
                        myContact.ID = countContact; // мое временное поле

                        string s = DateTime.Now.ToString() + " " + myContact.Author.Fname + " " + myContact.Author.Lname;
                        TextBlock textBlock = new TextBlock();
                        TextBlock textBlockS = new TextBlock();
                        textBlockS.Background = new SolidColorBrush(Color.FromRgb(231, 234, 237));
                        textBlockS.Text = s;
                        textBlockS.FontSize = 14;
                        textBlock.Width = 600;
                        textBlock.FontSize = 18;
                        textBlock.Foreground = new SolidColorBrush(Colors.White);
                        textBlock.Background = new SolidColorBrush(Color.FromRgb(47, 123, 195));
                     
                        textBlock.Text = TextBox_Message.Text;
                        textBlock.TextWrapping = TextWrapping.Wrap;

                        ListBoxItem listItem = new ListBoxItem();
                        ListBoxItem listItem2 = new ListBoxItem();
                        listItem.Content = "";
          
                        ListMessage.Items.Add(listItem);

                        listItem = new ListBoxItem();
                        listItem.Content = textBlock;
                        listItem2.Content = textBlockS;
                        listItem.Width = ListMessage.ActualWidth - 15;
                        ListMessage.Items.Add(listItem2);
                        ListMessage.Items.Add(listItem);
                        ListMessage.ScrollIntoView(listItem);

                        int countFile = 0;
                        foreach (MyFile myFile in myContact.ScreenShots) {
                            countFile++;
                            if (myFile.Extansion == ".jpg" || myFile.Extansion == ".bmp" || myFile.Extansion == ".png") {
                                var ms = new System.IO.MemoryStream(myFile.FileArray);
                                BitmapImage bitmapImage = new BitmapImage();
                                bitmapImage.BeginInit();
                                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                                bitmapImage.StreamSource = ms;
                                bitmapImage.EndInit();

                                Image image = new Image();
                                image.Source = bitmapImage;
                                image.Width = 180;

                                listItem = new ListBoxItem();
                                Border border = new Border();
                                border.Child = image;
                                border.BorderThickness = new Thickness(5, 5, 5, 5);
                                border.BorderBrush = new SolidColorBrush(Color.FromRgb(47, 123, 195));
                                listItem.Content = border;

                                List<object> list = new List<object>();
                                list.Add(myCurrentRequest.ID + "\\" + countContact); // имя папки
                                list.Add(myCurrentRequest.ID + "\\" + countContact + "\\" + countFile + myFile.Extansion); // имя картинки
                                list.Add(null); // массив
                                listItem.Tag = list;

                                listItem.Width = ListMessage.ActualWidth - 15;
                                //ListMessage.Items.Add(s);
                                ListMessage.Items.Add(listItem);
                                ListMessage.ScrollIntoView(listItem);
                            }
                            else {
                                Image image = new Image();
                                Uri iconUri = new Uri(@"Image/document.png", UriKind.Relative);
                                image.Source = BitmapFrame.Create(iconUri);
                                image.Width = 180;

                                image.Tag = myFile.FileArray;

                                listItem = new ListBoxItem();
                                Border border = new Border();
                                border.Child = image;
                                border.BorderThickness = new Thickness(5, 5, 5, 5);
                                border.BorderBrush = new SolidColorBrush(Color.FromRgb(47, 123, 195));
                                listItem.Content = border;

                                List<object> list = new List<object>();
                                list.Add(myCurrentRequest.ID + "\\" + countContact); // имя папки
                                list.Add(myCurrentRequest.ID + "\\" + countContact + "\\" + countFile + myFile.Extansion); // имя картинки
                                list.Add(myFile.FileArray); // массив
                                listItem.Tag = list;

                                listItem.Width = ListMessage.ActualWidth - 15;
                                //ListMessage.Items.Add(s);
                                ListMessage.Items.Add(listItem);
                                ListMessage.ScrollIntoView(listItem);
                            }
                        }

                        TextBox_Message.Text = "";
                        myContact = new MyContact();
                        L_Count.Content = 0;
                        L_Count.Visibility = Visibility.Collapsed;

                        if (MyImage != null) {
                            MyImage.Clear();
                        }
                    }
                
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void TextMessage_GotFocus(object sender, RoutedEventArgs e) {
            if (TextBox_Message.Text == "Длина сообщения не больше 1000 символов") {
                TextBox_Message.Text = "";
                TextBox_Message.Opacity = 1;
            }
        }

        private void TextMessage_LostFocus(object sender, RoutedEventArgs e) {
            if (TextBox_Message.Text == "") {
                TextBox_Message.Opacity = 0.6;
                TextBox_Message.Text = "Длина сообщения не больше 1000 символов";
            }
        }

        private void Button_StatusChange_Click(object sender, RoutedEventArgs e) {
            if ((bool)(Button_StatusChange.Tag) == false) { // Берем в работу 
                bool result = ServiceContext.Accept_Refuse_The_Request(supportSpecialist.ID, myCurrentRequest.ID);

                if (result) {
                    Button_StatusChange.Tag = true;
                    Button_StatusChange.Content = "Вернуть в входящие";

                    Button_StatusClose.IsEnabled = true;
                    Button_Ok.IsEnabled = true;
                    Button_File.IsEnabled = true;

                    TextBox_Message.IsEnabled = true;
                }
            }
            else { // Возвращаем во входящие
                Button_StatusChange.Tag = false;
                Button_StatusChange.Content = "Взять в рботу";

                Button_StatusClose.IsEnabled = false;
                Button_Ok.IsEnabled = false;
                Button_File.IsEnabled = false;

                TextBox_Message.IsEnabled = false;
            }
        }

        private void Button_StatusClose_Click(object sender, RoutedEventArgs e) {
            bool result = ServiceContext.Close_Request(supportSpecialist.ID, myCurrentRequest.ID);

            if (result) {
                this.Close();
            }
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Min_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        } // Button_Min_Click

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        } // Window_MouseLeftButtonDown

        private void TextMessage_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                try
                {

                    Author author = new Author();
                    author.ID = supportSpecialist.ID;
                    author.Lname = supportSpecialist.Lname;
                    author.Fname = supportSpecialist.Fname;

                    myContact.Author = author;
                    myContact.Request_ID = myCurrentRequest.ID;
                    myContact.Message = TextBox_Message.Text;
                    myContact.IsFromClient = false;

                    if (myContact.ScreenShots == null)
                    {
                        myContact.ScreenShots = (new List<MyFile>()).ToArray();
                    }
                    myContact.FilesCount = myContact.ScreenShots.Count();

                    bool result = ServiceContext.Post_Appeal_Inside_Request(myCurrentRequest, myContact);

                    if (result)
                    {
                        countContact++;
                        myContact.ID = countContact; // мое временное поле

                        string s = DateTime.Now.ToString() + " " + myContact.Author.Fname + " " + myContact.Author.Lname;
                        TextBlock textBlock = new TextBlock();
                        TextBlock textBlockS = new TextBlock();
                        textBlockS.Background = new SolidColorBrush(Color.FromRgb(231, 234, 237));
                        textBlockS.Text = s;
                        textBlockS.FontSize = 14;
                        textBlock.Width = 600;
                        textBlock.FontSize = 18;
                        textBlock.Foreground = new SolidColorBrush(Colors.White);
                        textBlock.Background = new SolidColorBrush(Color.FromRgb(47, 123, 195));

                        textBlock.Text = TextBox_Message.Text;
                        textBlock.TextWrapping = TextWrapping.Wrap;

                        ListBoxItem listItem = new ListBoxItem();
                        ListBoxItem listItem2 = new ListBoxItem();
                        listItem.Content = "";
                        ListMessage.Items.Add(listItem);

                        listItem = new ListBoxItem();
                        listItem.Content = textBlock;
                        listItem2.Content = textBlockS;
                        listItem.Width = ListMessage.ActualWidth - 15;
                        ListMessage.Items.Add(listItem2);
                        ListMessage.Items.Add(listItem);
                        ListMessage.ScrollIntoView(listItem);

                        int countFile = 0;
                        foreach (MyFile myFile in myContact.ScreenShots)
                        {
                            countFile++;
                            if (myFile.Extansion == ".jpg" || myFile.Extansion == ".bmp" || myFile.Extansion == ".png")
                            {
                                var ms = new System.IO.MemoryStream(myFile.FileArray);
                                BitmapImage bitmapImage = new BitmapImage();
                                bitmapImage.BeginInit();
                                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                                bitmapImage.StreamSource = ms;
                                bitmapImage.EndInit();

                                Image image = new Image();
                                image.Source = bitmapImage;
                                image.Width = 180;

                                listItem = new ListBoxItem();
                                Border border = new Border();
                                border.Child = image;
                                border.BorderThickness = new Thickness(5, 5, 5, 5);
                                border.BorderBrush = new SolidColorBrush(Color.FromRgb(47, 123, 195));
                                listItem.Content = border;

                                List<object> list = new List<object>();
                                list.Add(myCurrentRequest.ID + "\\" + countContact); // имя папки
                                list.Add(myCurrentRequest.ID + "\\" + countContact + "\\" + countFile + myFile.Extansion); // имя картинки
                                list.Add(null); // массив
                                listItem.Tag = list;

                                listItem.Width = ListMessage.ActualWidth - 15;
                                //ListMessage.Items.Add(s);
                                ListMessage.Items.Add(listItem);
                                ListMessage.ScrollIntoView(listItem);
                            }
                            else
                            {
                                Image image = new Image();
                                Uri iconUri = new Uri(@"Image/document.png", UriKind.Relative);
                                image.Source = BitmapFrame.Create(iconUri);
                                image.Width = 180;

                                image.Tag = myFile.FileArray;

                                listItem = new ListBoxItem();
                                Border border = new Border();
                                border.Child = image;
                                border.BorderThickness = new Thickness(5, 5, 5, 5);
                                border.BorderBrush = new SolidColorBrush(Color.FromRgb(47, 123, 195));
                                listItem.Content = border;

                                List<object> list = new List<object>();
                                list.Add(myCurrentRequest.ID + "\\" + countContact); // имя папки
                                list.Add(myCurrentRequest.ID + "\\" + countContact + "\\" + countFile + myFile.Extansion); // имя картинки
                                list.Add(myFile.FileArray); // массив
                                listItem.Tag = list;

                                listItem.Width = ListMessage.ActualWidth - 15;
                                //ListMessage.Items.Add(s);
                                ListMessage.Items.Add(listItem);
                                ListMessage.ScrollIntoView(listItem);
                            }
                        }

                        TextBox_Message.Text = "";

                        myContact = new MyContact();
                    }
                    L_Count.Content = 0;
                    L_Count.Visibility = Visibility.Collapsed;
                    MyImage.Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        } // TextMessage_KeyDown

        private void ListMessage_MouseDoubleClick(object sender, MouseButtonEventArgs e) {
            try {
                ListBoxItem listBoxItem = (ListBoxItem)(((ListBox)sender).SelectedItem);

                if (listBoxItem != null && listBoxItem.Content is Border) {
                    List<object> list = (List<object>)listBoxItem.Tag;
                    string pathDir = (string)list[0];
                    string pathFile = (string)list[1];
                    byte[] b = (byte[])list[2];

                    Directory.CreateDirectory(pathDir);

                    if (b == null) {
                        Border border = (Border)listBoxItem.Content;
                        Image image = (Image)border.Child;
                        var encoder = new PngBitmapEncoder();
                        encoder.Frames.Add(BitmapFrame.Create((BitmapSource)image.Source));
                        using (FileStream stream = new FileStream(pathFile, FileMode.Create))
                            encoder.Save(stream);
                    }
                    else {
                        File.WriteAllBytes(pathFile, b);
                    }

                    Process.Start(pathFile);
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

       
    }
}
