﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TP.ServiceReference1;

namespace TP {
    /// <summary>
    /// Логика взаимодействия для NewProduct_Window.xaml
    /// </summary>
    public partial class NewProduct_Window : Window {

        Service1Client ServiceContext;
        MyProduct myProduct;
        List<MySubjectLocal> mySubjectLocals;
        bool toChange;

        public NewProduct_Window(Service1Client ServiceContext) {
            InitializeComponent();
            this.ServiceContext = ServiceContext;
            this.toChange = false;
            myProduct = new MyProduct();
        }

        public NewProduct_Window(Service1Client ServiceContext, MyProduct myProduct) {
            InitializeComponent();
            this.ServiceContext = ServiceContext;
            this.toChange = true;
            this.myProduct = myProduct;
        }

        private void Button_OK_Click(object sender, RoutedEventArgs e) {
            try {
                myProduct.Name = TextName.Text;

                List<int> subjectIDs = new List<int>();
                foreach (MySubjectLocal item in mySubjectLocals) {
                    if (item.CheckBox == true) {
                        subjectIDs.Add(item.mySubject.ID);
                    }
                }

                bool result = false;
                result = ServiceContext.Registr_New_Product(myProduct, subjectIDs.ToArray(), toChange);

                if (result) {
                    this.Close();
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

      

        private void Window_Loaded(object sender, RoutedEventArgs e) {
            try {
                List<MySubject> mySubjects = ServiceContext.Get_All_Subjects().ToList();

                if (mySubjects != null) {
                    mySubjectLocals = new List<MySubjectLocal>();
                    foreach (MySubject item in mySubjects) {
                        MySubjectLocal mySubjectLocal = new MySubjectLocal();
                        mySubjectLocal.mySubject = item;
                        mySubjectLocals.Add(mySubjectLocal);
                    }

                    if (toChange == true) { // Поменять на true
                        TextName.Text = myProduct.Name;
                        mySubjects = ServiceContext.Get_MySubject_By_Product(myProduct.ID).ToList();

                        foreach (MySubject item in mySubjects) {
                            foreach (MySubjectLocal itemLocal in mySubjectLocals) {
                                if (item.ID == itemLocal.mySubject.ID) {
                                    itemLocal.checkBox = true;
                                }
                            }
                        }
                    }

                    ObservableCollection<MySubjectLocal> observableCollection = new ObservableCollection<MySubjectLocal>(mySubjectLocals);
                    CollectionViewSource collection = new CollectionViewSource() { Source = observableCollection };
                    gridSubject.ItemsSource = collection.View;
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        } // Button_Close_Click

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.DragMove();
            }
            catch
            {

            }
        } // Window_MouseLeftButtonDown
    }
}
