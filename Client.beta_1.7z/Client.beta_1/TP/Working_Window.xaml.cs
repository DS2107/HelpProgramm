﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Runtime.Caching;
using TP.SupportServiceContext;
using System.Collections.ObjectModel;
using System.IO;

namespace TP
{
    /// <summary>
    /// Логика взаимодействия для Working_Window.xaml
    /// </summary>
    public partial class Working_Window : Window
    {
        SupportServiceContext.Service1Client ServiceContext;
        MyRequest myRequestMessage;

        bool Window_State = true;

        public Working_Window()
        {
            InitializeComponent();
            L_Login.Content = MainWindow.myUser.Login;
            L_FName.Content = MainWindow.myUser.Fname;
            L_LName.Content = MainWindow.myUser.Lname;
            L_Company.Content = MainWindow.myUser.CompanyName;
          
            View_ListRequest();
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.DragMove();
            }
            catch
            {

            }
           
        } // Window_MouseLeftButtonDown

        /// <summary>
        /// Отобразить список запросов в GridView
        /// </summary>
        public void View_ListRequest()
        {
            if (dateFrom.SelectedDate == null) {
                DateTime dateTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1, 0, 0, 0);
                dateFrom.SelectedDate = dateTime;
            }
            if (dateTo.SelectedDate == null) {
                DateTime dateTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 59, 59);
                dateTo.SelectedDate = dateTime;
            }

            Author author = new Author();
            author.ID = MainWindow.myUser.ID;
            author.Fname = MainWindow.myUser.Fname;
            author.Lname = MainWindow.myUser.Lname;

            List<MyRequest> ListRequest;
            //ListRequest = MainWindow.ServiceContext.Get_Short_RequestsList_For_CurrentUser(author).ToList();
            ListRequest = MainWindow.ServiceContext.Get_Short_RequestsList_For_CurrentUser_ByDate(author.ID, dateFrom.SelectedDate.Value, dateTo.SelectedDate.Value).ToList();

            if (ListRequest != null)
             {
                 ObservableCollection<MyRequest> observableCollection = new ObservableCollection<MyRequest>(ListRequest);
                 CollectionViewSource collection = new CollectionViewSource() { Source = observableCollection };
                 DataGrid_Requests.ItemsSource = collection.View;
             } // if
             
        } // View_ListRequest

        /// <summary>
        /// Если пользователь хочет разлогиниться 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_LogOut_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        } // Button_LogOut_Click

        private void DataGrid_Requests_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            myRequestMessage = (MyRequest)(((DataGrid)sender).SelectedItem);

            Message_Window message_Window = new Message_Window();
            message_Window.getInfo += Message_Window_getInfo;
            message_Window.ShowDialog();
        } // DataGrid_Requests_MouseDoubleClick

        private object Message_Window_getInfo()
        {
            return myRequestMessage;
        } // Message_Window_getInfo
     
        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        } // Button_Close_Click

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            MainWindow.ServiceContext.Disconnect_User(MainWindow.myUser.Login);
        } // Window_Closing

        private void Button_Min_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        } // Button_Min_Click

        private void Button_MaxMin_Click(object sender, RoutedEventArgs e)
        {
            if (Window_State == true)
            {
                WindowState = WindowState.Maximized;
                Window_State = false;
            }
            else
            {
                WindowState = WindowState.Normal;
                Window_State = true;
            }
        } // Button_MaxMin_Click

        private void Buttno_New_Message_Click(object sender, RoutedEventArgs e)
        {
            Treatment_Window new_message = new Treatment_Window();
            new_message.ShowDialog();
            View_ListRequest();
        } // Buttno_New_Message_Click

        private void Button_LogOut_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        } // Button_LogOut_Click_1

        private void Buttno_UPDATE_Click(object sender, RoutedEventArgs e)
        {
            View_ListRequest();
        } // Buttno_UPDATE_Click

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.F5)
            {
                View_ListRequest();
            } // if

        } // Window_KeyDown

        private void ButtonSearch_Click(object sender, RoutedEventArgs e) {
            View_ListRequest();
        }

        private void Button_LogOut_Click_2(object sender, RoutedEventArgs e)
        {
            NewPassword newPassword = new NewPassword();
            newPassword.ShowDialog();
            if(NewPassword.pas)
            {
                MainWindow main = new MainWindow();
                main.Show();
                this.Close();
            }
           
        }

        private void Button_Help_Click(object sender, RoutedEventArgs e)
        {
            WindowHelp help = new  WindowHelp();
            help.ShowDialog();
        }
    }
}
