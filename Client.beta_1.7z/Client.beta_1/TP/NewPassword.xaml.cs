﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TP
{
    /// <summary>
    /// Логика взаимодействия для NewPassword.xaml
    /// </summary>
    public partial class NewPassword : Window
    {
        public static bool pas;
        public NewPassword()
        {
            InitializeComponent();
        }

        private void Button_NewMessage_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        } // Button_NewMessage_Click

        private void Button_NewPassword_Click(object sender, RoutedEventArgs e)
        {
           
            try
            {
               pas =  MainWindow.ServiceContext.Change_User_Password(Old_Password.Password.ToString(), New_Password.Password.ToString(), MainWindow.myUser.ID);
                if (pas == true)
                {
                    MainWindow.ServiceContext.Disconnect_User(MainWindow.myUser.Login);
                    this.Close();
                }
                
                else
                { 
                    MessageBox.Show("Что то не так");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        } // Button_NewPassword_Click
    }
}
