﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ServiceModel;
using TP.SupportServiceContext;


namespace TP
{
    public partial class MainWindow : Window
    {
        // Информация о пользователе 
        public static MyUser myUser;

        // Связь с сервером
        static public SupportServiceContext.Service1Client ServiceContext;

        public MainWindow()
        {
            InitializeComponent();
            TB_Login.Focus();
            ServiceContext = new Service1Client();
        } // MainWindow

        private void TBlock_autorization_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            login();
        } // TBlock_autorization_MouseLeftButtonDown

        public void login()
        {
            myUser = ServiceContext.UserConnection(TB_Login.Text, PB_Password.Password);

            if (myUser != null)
            {
                Working_Window work = new Working_Window();
                work.Show();
                this.Close();

            } // if

            else
            {
                MessageBox.Show("Данные некорректные");
            }
        } // login Проверка авторизации

        // Работа с окном 
        #region Window 
        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.DragMove();
            }
            catch
            {

            }
        } // Window_MouseLeftButtonDown

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                this.Close();
            } // if

            if(e.Key == Key.Down)
            {
          
                PB_Password.Focus();
            } // if

            if(e.Key == Key.Up)
            {
                TBlock_autorization.Focus();
            }

        } // Window_KeyDown

        private void TB_Login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)           
                login();
           

            if (e.Key == Key.Down)        
                PB_Password.Focus();
           
        } // TB_Login_KeyDown

       

        private void PB_Password_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                login();
            } // if
          
        } // PB_Password_KeyDown


        #endregion

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {


                ServiceContext.Disconnect_User(myUser.Login);
            }
            catch
            {

            }
        }
    }
}
