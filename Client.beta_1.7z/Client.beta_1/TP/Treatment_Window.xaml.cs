﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Caching;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TP.SupportServiceContext;

namespace TP
{

    /// <summary>
    /// Логика взаимодействия для Treatment_Window.xaml
    /// </summary>
    public partial class Treatment_Window : Window
    {
       
        Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
        // Список продуктов и тем 
        static List<MySubjectProductUser> mySubjectProductUsers = new List<MySubjectProductUser>();
        // Список продуктов
        static List<string> product = new List<string>();
        // Список тем
        static List<string> theme = new List<string>();
        // Данные пользователя, который создает запрос 
        Author author = new Author();
        // Отметка о получении сообщения
        bool treatment;

        List<string> MyImage = new List<string>();

        MyFile myFile;

        MyContact myContact = new MyContact();

        public Treatment_Window()
        {
            InitializeComponent();
            // Длина текстового сообщения
            TextBox_Message.MaxLength = 1000;
            TextBox_Message.Opacity = 0.6;
            L_Count_Image.Visibility = Visibility.Collapsed;

            try
            {              
                author.ID = MainWindow.myUser.ID;
                author.Fname = MainWindow.myUser.Fname;
                author.Lname = MainWindow.myUser.Lname;
                mySubjectProductUsers = MainWindow.ServiceContext.Get_Products_Subjects_For_User(author).ToList();
            }
            catch
            {

            }
        } // Treatment_Window

        private void CB_product_DropDownOpened(object sender, EventArgs e)
        {
            CB_product.Items.Clear();
            CB_Theme.SelectedItem = null;
            foreach (var s in mySubjectProductUsers)
            {
                CB_product.Items.Add(s.product.Name);
            } 
        }  // CB_product_DropDownOpened

        private void CB_Theme_DropDownOpened(object sender, EventArgs e)
        {
            CB_Theme.Items.Clear();
            if(CB_product.Items == null)          
                return;
           
            foreach (var s in mySubjectProductUsers)
            {
                if (s.product.Name == CB_product.SelectedItem.ToString())
                    foreach(var z in s.subjects)
                    {
                        CB_Theme.Items.Add( z.Name);
                    }
            } // if


        } // CB_Theme_DropDownOpened

        #region Window
        /// <summary>
        /// Отображение символов в TextBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TextBox_Message_GotFocus(object sender, RoutedEventArgs e)
        {
            if (TextBox_Message.Text == "Длина сообщения не больше 1000 символов") {
                TextBox_Message.Opacity = 1;
                TextBox_Message.Text = "";
            }
        } // TextBox_Message_GotFocus

        /// <summary>
        /// Отображение символов в TextBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TextBox_Message_LostFocus(object sender, RoutedEventArgs e)
        {
            if (TextBox_Message.Text == "")
            {
                TextBox_Message.Opacity = 0.6;
                TextBox_Message.Text = "Длина сообщения не больше 1000 символов";
            }
        } // TextBox_Message_LostFocus

        /// <summary>
        /// Движение окна
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.DragMove();
            }
            catch
            {

            }

        } // Window_MouseLeftButtonDown

        /// <summary>
        /// Отменить запрос и закрыть окно 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Cancel_Click(object sender, RoutedEventArgs e)
        {
            Working_Window work = new Working_Window();
            work.Show();
            this.Close();
        } // Button_Cancel_Click


        private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                if (popup2.IsOpen == true || popup1.IsOpen == true)
                {
                    popup2.IsOpen = false;
                    popup1.IsOpen = false; 
                }
            }

        }



        #endregion

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        } // Button_Close_Click

        private void Button_NewMessage1_Click(object sender, RoutedEventArgs e)
        {
            // создаем классы для заполнения и передачи их на сервер          
            MyProduct product = new MyProduct();
            MySubject mySubject = new MySubject();

            try
            {
                // Заполнение классов   
                if (TextBox_Message.Text.Length > 0 && TextBox_Message.Text != "Длина сообщения не больше 1000 символов"
                    && CB_product.SelectedItem != null && CB_Theme.SelectedItem != null)
                {
                    myContact.Author = author;
                    myContact.Message = TextBox_Message.Text;
                    myContact.IsFromClient = true;
                    myContact.FilesCount = MyImage.Count;

                    MyRequest myRequest = new MyRequest();
                    foreach (var p in mySubjectProductUsers)
                    {
                        if (CB_product.SelectedItem.ToString() == p.product.Name)
                        {
                            product.ID = p.product.ID;
                            product.Name = p.product.Name;
                        } // if
                    }
                    foreach (var s in mySubjectProductUsers)
                    {
                        foreach (var s1 in s.subjects)
                        {
                            if (s1.Name == CB_Theme.SelectedItem.ToString())
                            {
                                mySubject.ID = s1.ID;
                                mySubject.Name = s1.Name;
                            } // if
                        }
                    }
                    myRequest.Product = product;
                    myRequest.User = MainWindow.myUser;
                    myRequest.Subject = mySubject;

                    // Отправка сообщения 
                    treatment = MainWindow.ServiceContext.Post_New_Appeal(myRequest, myContact);
                    this.Close();
                } // if

                else if (treatment == false)
                {
                    popup2.IsOpen = true;
                } // if
                else
                {
                    popup2.IsOpen = true;
                }
                if (treatment == true)
                {
                    CB_product.Items.Clear();
                    TextBox_Message.Clear();
                    CB_Theme.Items.Clear();
                    popup1.IsOpen = true;


                } // if
                L_Count_Image.Content = 0;
                L_Count_Image.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message);

            }
        } // Button_NewMessage1_Click

        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //dlg.DefaultExt = ".png";
            //dlg.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif";
            dlg.Multiselect = true;
            Nullable<bool> result = dlg.ShowDialog();

            myFile = new MyFile();
            if (result == true)
            {
                for (int i = 0; i < dlg.FileNames.Length; i++)
                {

                    MyImage.Add(dlg.FileNames[i]);

                    FileInfo file = new FileInfo(dlg.FileNames[i].ToString());
                    myFile.Extansion = file.Extension;
                    myFile.FileArray = File.ReadAllBytes(dlg.FileNames[i].ToString());


                    List<MyFile> list = new List<MyFile>();
                    list.Add(myFile);
                    //myContact.ScreenShots.ToList().Add(myFile);

                    myContact.ScreenShots = list.ToArray();

                    if (MyImage.Count == 3)
                        break;
                }
                L_Count_Image.Content = MyImage.Count;
                L_Count_Image.Visibility = Visibility.Visible;
            }
        } // Image_MouseLeftButtonDown
    }
}
